var Product = require('../models/product');

var mongoose = require('mongoose');

mongoose.connect('localhost:27017/shopping');

var products = [ 
    new Product({
        imagePath: 'https://triosdevelopers.com/~F.Ali/10MWD/images/googlepixel2xl.jpeg' ,
        name: 'Google Pixel 2XL',
        description: 'Google Pixel 2XL, Android powered smartphone with powers that will enable you to accomplish your tasks with breeze and comfort. Enjoy clean, faster and fluid interface!',
        price: 800
    }),

    new Product({
        imagePath: 'https://triosdevelopers.com/~F.Ali/10MWD/images/huaweip20pro.jpg' ,
        name: 'Huawei P20 Pro',
        description: 'Huawei P20 Pro, Android powered smartphone. Fulfil your dreams and imaginations by using one of the most powerfull camera phone!',
        price: 1000
    }),

    new Product({
        imagePath: 'https://triosdevelopers.com/~F.Ali/10MWD/images/iphone8.png' ,
        name: 'IPhone 8',
        description: 'Iphone 8, top phone from Apple. Enjoy the power of IOS with no limits!',
        price: 700
    }),

    new Product({
        imagePath: 'https://triosdevelopers.com/~F.Ali/10MWD/images/iphone8plus.jpg' ,
        name: 'IPhone 8 Plus',
        description: 'IPhone 8 Plus,  bigger screen, bigger battery, bigger achievements. One of the best from Apple to make you feel special at anytime!',
        price: 850
    }),

    new Product({
        imagePath: 'https://triosdevelopers.com/~F.Ali/10MWD/images/iphonex.jpg' ,
        name: 'IPhone X',
        description: 'IPhone X. The best smartphone from Apple. Unleash your inner beast and satisfy your thirst for the best in Apple world!',
        price: 1000
    }),

    new Product({
        imagePath: 'https://triosdevelopers.com/~F.Ali/10MWD/images/lgv35thinq.jpg' ,
        name: 'LG V35 Thinq',
        description: 'LG V35 Thinq, Android powered highly evolved, capable and smartphone from LG. More secured and realiable phone then the competitiors. Life is always good with LG!',
        price: 950
    }),

    new Product({
        imagePath: 'https://triosdevelopers.com/~F.Ali/10MWD/images/motorolamotoz2force.jpg' ,
        name: 'Motorola Moto Z2 Force',
        description: 'Motorola Moto Z2 Force. Android powered Sony smartphone for you to play, enjoy and acheive success on the go!',
        price: 850
    }),

    new Product({
        imagePath: 'https://triosdevelopers.com/~F.Ali/10MWD/images/nokia8sirocco.jpg' ,
        name: 'Nokia 8 Sirocco',
        description: 'Nokia 8 Sirocco Android powered smartphone, one of the best Nokia has to offer in Android world. You never go wrong with Nokia, Nokia has done it again!',
        price: 900
    }),

    new Product({
        imagePath: 'https://triosdevelopers.com/~F.Ali/10MWD/images/samsungnote8.png' ,
        name: 'Samsung Galaxy Note 8',
        description: 'Samsung Galaxy Note 8 Android powered smartphone. Its a phone, its a note, its everything. Transform your phone into a notepad and unleash your creativity!',
        price: 1100
    }),

    new Product({
        imagePath: 'https://triosdevelopers.com/~F.Ali/10MWD/images/samsungs9.jpeg' ,
        name: 'Samsung Galaxy S9',
        description: 'Samsung Galaxy S9 Android powered smartphone from Samsung. Enjoy your life dreams with this unique smartphone expereince!',
        price: 700
    }),

    new Product({
        imagePath: 'https://triosdevelopers.com/~F.Ali/10MWD/images/samsungs9plus.jpeg' ,
        name: 'Samsung Galaxy S9 Plus',
        description: 'Samsung Galaxy S9 Plus Android powered smartphone. Samsung has done it again, one of the best top mobile expereince you can get in Android world that comes from one the best phone maker!',
        price: 850
    }),

    new Product({
        imagePath: 'https://triosdevelopers.com/~F.Ali/10MWD/images/sonyxperiaxz2premium.jpg' ,
        name: 'Sony Xperia Z2 Premium',
        description: 'Sony Xperia Z2 Premium. The best Sony Android powered smartphone you can get and feel premium and luxury right from the beginning as soon as you start using it!',
        price: 800
    })
];

//helper variable to disconnet after saving all products
var done = 0;
for ( var i = 0; i < products.length; i++ ){
    products[i].save(function(err, result){
        done++;
        if ( done == products.length){
            exit();
        }
    });
}

function exit(){
    mongoose.disconnect();
}